import 'package:flutter/material.dart';
import 'package:mightyweb/main.dart';
import 'package:mightyweb/screen/DashboardScreen.dart';
import 'package:mightyweb/screen/WalkThroughScreen.dart';
import 'package:mightyweb/utils/AppWidget.dart';
import 'package:mightyweb/utils/constant.dart';
import 'package:nb_utils/nb_utils.dart';

class SplashScreen extends StatefulWidget {
  static String tag = '/SplashScreen2';

  @override
  SplashScreenState createState() => SplashScreenState();
}

class SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    setStatusBarColor(appStore.primaryColors, statusBarBrightness: Brightness.light);
    await Future.delayed(Duration(seconds: 2));
    if (getStringAsync(IS_WALKTHROUGH) == "true") {
      if (getBoolAsync(IS_FIRST_TIME, defaultValue: true)) {
        WalkThroughScreen().launch(context, isNewTask: true);
      } else {
        DashBoardScreen().launch(context, isNewTask: true);
      }
    } else {
      DashBoardScreen().launch(context, isNewTask: true);
    }
    setState(() {});
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: getStringAsync(THEME_STYLE) == THEME_STYLE_GRADIENT
          ? Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [
                  getColorFromHex(
                    getStringAsync(GRADIENT1),
                    defaultColor: Color(0xFF4358DD),
                  ),
                  getColorFromHex(
                    getStringAsync(GRADIENT2),
                    defaultColor: Color(0xFF4358DD),
                  ),
                ]),
              ),
              child: Container(
                alignment: Alignment.center,
                height: 120,
                decoration: boxDecorationWithRoundedCorners(borderRadius: radius(10)),
                width: 120,
                child: cachedImage(getStringAsync(APPLOGO), fit: BoxFit.cover).cornerRadiusWithClipRRect(10),
              ).center(),
            )
          : Container(
              color: appStore.primaryColors,
              child: cachedImage(getStringAsync(APPLOGO), fit: BoxFit.contain, height: 150, width: 150).cornerRadiusWithClipRRect(10).center(),
            ),
    );
  }
}
