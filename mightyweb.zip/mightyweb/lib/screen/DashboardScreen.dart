import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:mightyweb/component/BottomNavigationComponent.dart';
import 'package:mightyweb/main.dart';
import 'package:mightyweb/model/MainResponse.dart';
import 'package:mightyweb/utils/constant.dart';
import 'package:nb_utils/nb_utils.dart';

import '../main.dart';
import 'HomeScreen.dart';

class DashBoardScreen extends StatefulWidget {
  static String tag = '/DashBoardScreen';

  final String? url;

  DashBoardScreen({this.url});

  @override
  DashBoardScreenState createState() => DashBoardScreenState();
}

class DashBoardScreenState extends State<DashBoardScreen> {
  late List<MenuStyle> mBottomMenuList;
  List<Widget> widgets = [];

  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    setStatusBarColor(appStore.primaryColors, statusBarBrightness: Brightness.light);

    Iterable mBottom = jsonDecode(getStringAsync(BOTTOMMENU));
    mBottomMenuList = mBottom.map((model) => MenuStyle.fromJson(model)).toList();

    if (getStringAsync(NAVIGATIONSTYLE) == NAVIGATION_STYLE_BOTTOM_NAVIGATION) {
      for (int i = 0; i < appStore.mBottomNavigationList.length; i++) widgets.add(HomeScreen(mUrl: mBottomMenuList[i].url));
    }
    setState(() {});
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return getStringAsync(NAVIGATIONSTYLE) == NAVIGATION_STYLE_BOTTOM_NAVIGATION
        ? SafeArea(
            child: Scaffold(
              backgroundColor: context.scaffoldBackgroundColor,
              bottomNavigationBar: getStringAsync(AD_MOB_BANNER_ID).isEmpty
                  ? BottomNavigationComponent()
                  : Container(
                      height: 106,
                      child: Column(
                        children: [
                          AdWidget(
                            ad: BannerAd(
                              adUnitId: kReleaseMode ? getStringAsync(AD_MOB_BANNER_ID) : BannerAd.testAdUnitId,
                              size: AdSize.banner,
                              request: AdRequest(),
                              listener: BannerAdListener(),
                            )..load(),
                          ),
                          Align(alignment: Alignment.bottomCenter, child: BottomNavigationComponent())
                        ],
                      ),
                    ),
              body: Observer(
                builder: (_) => widgets[appStore.currentIndex],
              ),
            ),
          )
        : HomeScreen();
  }
}
