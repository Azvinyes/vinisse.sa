import 'package:async/async.dart';
import 'package:flutter/material.dart';
import 'package:mightyweb/Network/NetworkUtils.dart';
import 'package:mightyweb/component/DeepLinkWidget.dart';
import 'package:mightyweb/component/NoInternetConnection.dart';
import 'package:mightyweb/main.dart';
import 'package:mightyweb/model/MainResponse.dart';
import 'package:mightyweb/screen/DashboardScreen.dart';
import 'package:mightyweb/screen/ErrorScreen.dart';
import 'package:mightyweb/screen/SplashScreen.dart';
import 'package:mightyweb/utils/bloc.dart';
import 'package:mightyweb/utils/loader.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:provider/provider.dart';

class DataScreen extends StatefulWidget {
  static String tag = '/SplashScreen';

  @override
  DataScreenState createState() => DataScreenState();
}

class DataScreenState extends State<DataScreen> with AfterLayoutMixin<DataScreen> {
  bool isWasConnectionLoss = false;
  AsyncMemoizer<MainResponse> mainMemoizer = AsyncMemoizer<MainResponse>();

  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      if (result == ConnectivityResult.none) {
        setState(() {
          isWasConnectionLoss = true;
        });
      } else {
        setState(() {
          isWasConnectionLoss = false;
        });
      }
    });
  }

  @override
  void afterFirstLayout(BuildContext context) {
    if (isMobile) {
      OneSignal.shared.setNotificationOpenedHandler((OSNotificationOpenedResult notification) async {
        String? urlString = await notification.notification.additionalData!["ID"];

        if (urlString.validate().isNotEmpty) {
          toast(urlString);
        }
      });
    }
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    DeepLinkBloc _bloc = DeepLinkBloc();
    return Scaffold(
      body: Stack(
        children: [
          Provider<DeepLinkBloc>(
            create: (context) => _bloc,
            dispose: (context, bloc) => bloc.dispose(),
            child: DeepLinkWidget(),
          ),
          FutureBuilder<MainResponse>(
            future: mainMemoizer.runOnce(() => fetchData()),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!.appconfiguration!.isSplashScreen == "true")
                  return SplashScreen();
                else
                  return SafeArea(
                    child: DashBoardScreen(),
                  );
              } else if (snapshot.hasError) {
                return isWasConnectionLoss == true ? ErrorScreen() : NoInternetConnection();
              }
              return Loaders(name: appStore.loaderValues).center();
            },
          ),
        ],
      ),
    );
  }
}
