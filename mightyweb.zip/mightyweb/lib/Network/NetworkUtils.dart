import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:mightyweb/main.dart';
import 'package:mightyweb/model/MainResponse.dart' as model;
import 'package:mightyweb/utils/colors.dart';
import 'package:mightyweb/utils/common.dart';
import 'package:mightyweb/utils/constant.dart';
import 'package:nb_utils/nb_utils.dart';

Future handleResponse(Response response) async {
  if (!await isNetworkAvailable()) {
    throw errorInternetNotAvailable;
  }

  if (response.statusCode.isSuccessful()) {
    return jsonDecode(response.body);
  } else {
    try {
      var body = jsonDecode(response.body);
      throw body['message'];
    } on Exception catch (e) {
      log(e);
      throw errorSomethingWentWrong;
    }
  }
}

Future<model.MainResponse> fetchData() async {
  final response = await http.Client().get(Uri.parse(BASE_URL + '/upload/mightyweb.json'));
  return await handleResponse(response).then((json) async {
    var mModel = model.MainResponse.fromJson(json);

    await setValue(URL, mModel.appconfiguration!.url.isEmptyOrNull ? 'https://www.google.com' : mModel.appconfiguration!.url);
    await setValue(IS_JAVASCRIPT_ENABLE, mModel.appconfiguration!.isJavascriptEnable);
    await setValue(IS_SPLASH_SCREEN, mModel.appconfiguration!.isSplashScreen);
    await setValue(IS_ZOOM_FUNCTIONALITY, mModel.appconfiguration!.isZoomFunctionality);
    await setValue(APPNAME, mModel.appconfiguration!.appName);
    await setValue(APP_LANGUAGE, mModel.appconfiguration!.appLanuguage);

    if (mModel.appconfiguration!.isWebrtc != null) {
      await setValue(IS_WEBRTC, mModel.appconfiguration!.isWebrtc);
    }
    if (mModel.appconfiguration!.isWalkthrough != null) {
      await setValue(IS_WALKTHROUGH, mModel.appconfiguration!.isWalkthrough);
    }
    if (mModel.appconfiguration!.appLogo != null) {
      await setValue(APPLOGO, mModel.appconfiguration!.appLogo);
    }
    if (mModel.appconfiguration!.floatingButton != null) {
      await setValue(FLOATING_LOGO, mModel.appconfiguration!.floatingButton);
    }
    if (mModel.appconfiguration!.isFloatingButton != null) {
      await setValue(IS_FLOATING, mModel.appconfiguration!.isFloatingButton);
    } else {
      await setValue(IS_FLOATING, "false");
    }

    if (mModel.appconfiguration!.floatingButtonStyle != null) {
      await setValue(FLOATING_STYLE, mModel.appconfiguration!.floatingButtonStyle);
    }

    await setValue(NAVIGATIONSTYLE, mModel.appconfiguration!.navigationStyle);
    await setValue(HEADERSTYLE, mModel.appconfiguration!.headerStyle);
    if (mModel.appconfiguration!.tabStyle != null) {
      await setValue(TAB_BAR_STYLE, mModel.appconfiguration!.tabStyle);
    }
    if (mModel.appconfiguration!.isPullRefresh != null) {
      await setValue(IS_PULL_TO_REFRESH, mModel.appconfiguration!.isPullRefresh);
    }

    if (mModel.appconfiguration!.isCookieEnable != null) {
      await setValue(IS_COOKIE, mModel.appconfiguration!.isCookieEnable);
    }

    await setValue(AD_MOB_BANNER_ID, mModel.admob!.admobBannerID);
    await setValue(AD_MOB_INTENTIALID, mModel.admob!.admobIntentialID);
    await setValue(AD_MOB_BANNER_ID_IOS, mModel.admob!.admobBannerIDIOS);
    await setValue(AD_MOB_INTENTIAL_ID_IOS, mModel.admob!.admobIntentialIDIOS);

    await setValue(MENU_STYLE, jsonEncode(mModel.menuStyle));

    await setValue(LOADER_STYLE, mModel.progressbar!.loaderStyle);
    appStore.setLoader(mModel.progressbar!.loaderStyle);

    await setValue(THEME_STYLE, mModel.theme!.themeStyle);
    if (getStringAsync(THEME_STYLE) == THEME_STYLE_CUSTOM) {
      await setValue(THEME_STYLE, mModel.theme!.customColor);
      appStore.setPrimaryColor(hexStringToHexInt(getStringAsync(THEME_STYLE)));
    } else if (getStringAsync(THEME_STYLE) == THEME_STYLE_DEFAULT) {
      appStore.setPrimaryColor(primaryColor1);
    } else if (getStringAsync(THEME_STYLE) == THEME_STYLE_GRADIENT) {
      await setValue(GRADIENT1, mModel.theme!.gradientColor1);
      await setValue(GRADIENT2, mModel.theme!.gradientColor2);
      appStore.setPrimaryColor(hexStringToHexInt(mModel.theme!.gradientColor1!));
    } else {
      await setValue(THEME_STYLE, mModel.theme!.themeStyle);
      var theme = getStringAsync(THEME_STYLE);
      try {
        for (var i = 0; i < themeName.length; i++) {
          if (themeName[i] == theme) {
            appStore.setPrimaryColor(hexStringToHexInt(colorName[i]));
            break;
          }
        }
      } catch (e) {
        print(e);
      }
    }
    await setValue(IS_SHOW_ABOUT, mModel.about!.isShowAbout);
    await setValue(WHATS_APP_NUMBER, mModel.about!.whatsAppNumber);
    await setValue(INSTA_GRAM_URL, mModel.about!.instagramUrl);
    await setValue(TWITTER_URL, mModel.about!.twitterUrl);
    await setValue(FACEBOOK_URL, mModel.about!.facebookUrl);
    await setValue(CALL_NUMBER, mModel.about!.callNumber);
    await setValue(SKYPE, mModel.about!.skype);
    await setValue(SNAPCHAT, mModel.about!.snapchat);
    await setValue(YOUTUBE, mModel.about!.youtube);
    await setValue(MESSENGER, mModel.about!.messenger);

    await setValue(ONESINGLE, mModel.onesignalConfiguration!.appId);

    await setValue(LEFTICON, jsonEncode(mModel.headerIcon!.lefticon));
    await setValue(RIGHTICON, jsonEncode(mModel.headerIcon!.righticon));

    if (mModel.menuStyle != null) {
      mModel.menuStyle.forEachIndexed((element, index) {
        if (element.status == "1") {
          appStore.addToBottomNavigationLis(element);
        }
      });
      await setValue(BOTTOMMENU, jsonEncode(appStore.mBottomNavigationList));
    }

    if (mModel.walkthrough != null) {
      mModel.walkthrough.forEachIndexed((element, index) {
        if (element.status == "1") {
          appStore.addToOnBoardList(element);
        }
      });
      await setValue(WALKTHROUGH, jsonEncode(appStore.mOnBoardList));
    }

    if (mModel.floatingButton != null) {
      mModel.floatingButton.forEachIndexed((element, index) {
        if (element.status == "1") {
          appStore.addToFabList(element);
        }
      });
      await setValue(FLOATING_DATA, jsonEncode(appStore.mFABList));
    }

    if (mModel.tabs != null) {
      mModel.tabs.forEachIndexed((element, index) {
        if (element.status == "1") {
          appStore.addToTabList(element);
        }
      });
      await setValue(TABS, jsonEncode(appStore.mTabList));
    }

    if (mModel.userAgentResponse != null) {
      mModel.userAgentResponse.forEachIndexed((element, index) async {
        if (element.status == "1") {
          if (isIos) {
            await setValue(USER_AGENT, element.ios!.isNotEmpty ? element.ios : "random");
          } else {
            await setValue(USER_AGENT, element.android!.isNotEmpty ? element.android : "random");
          }
        }
      });
    }
    return mModel;
  }).catchError((e) {
    log(e);
    throw e.toString();
  });
}
